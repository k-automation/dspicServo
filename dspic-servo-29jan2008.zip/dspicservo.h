//---------------------------------------------------------------------
//	File:		dspicservo.h
//
//	Written By:	Lawrence Glaister VE7IT
//
// Purpose: Various header info for the project
//      
// 
//---------------------------------------------------------------------
//
// Revision History
// March 11 2006 --   formatted into multi file project
// Sept 25 2006 -  6x pwm rate
//---------------------------------------------------------------------- 
// define which chip we are using (peripherals change)
#include <p30f4012.h>

// the following version string is printed on powerup (also in every object module)
#define CPWRT  "\r\ndspic-servo by L.Glaister\r\n"
#define VERSION "(c) 29-Jan-2008 by VE7IT"

// this number was tweaked by hand until serial port baud was correct
//#define FCY  (6000000 * 16 / 4)       // 24 MIPS ==> 6mhz osc * 16pll  / 4
#define FCY  (14318000 * 8 / 4)       // 28.636 MIPS ==> 14.318mhz osc * 8pll  / 4

/* define required pwm rate... dont make it too high as we loose resolution */
#define FPWM 16000		// 48000 gives approx +- 10 bit current control

// define some i/o bits for the various modules
#define STATUS_LED 	_LATE1		
#define SVO_DIR     _LATE2
#define SVO_NDIR    _LATE3	//inverted 

#define SVO_ENABLE   _RE8
#define PWM_INTR    _LATB1

// for some reason PI may not be defined in math.h on some systems
#ifndef M_PI
#define M_PI (3.14159265358979323846)
#endif

#define	TRUE	(1)
#define	FALSE	(0)	

struct PID{
	// the first block of params must survive powerfails and cksums
    // keep params together followed by cksum so that calc_cksum() works
    float pgain;		 /* param: proportional gain                 */
    float igain;		 /* param: integral gain                     */
    float dgain;		 /* param: derivative gain                   */
    float ff0gain;		 /* param: feedforward proportional          */
    float ff1gain;		 /* param: feedforward derivative            */
    float maxoutput;	 /* param: limit for PID output              */
    float deadband;		 /* param: deadband                          */
    float maxerror;		 /* param: limit for error                   */
    float maxerror_i;	 /* param: limit for integrated error        */
    float maxerror_d;	 /* param: limit for differentiated error    */
    float maxcmd_d;		 /* param: limit for differentiated cmd      */
	short multiplier;	 /* param: pc command multiplier             */
	short ticksperservo; /* param: number of 100us ticks/servo cycle */
    short cksum;		 /* data block cksum used to verify eeprom   */

	// the following block of temp vars is related to axis servo calcs
    // but should not be cksumed
    long int command;	/* commanded value */
    long int feedback;	/* feedback value */
    long int prev_cmd;	/* previous command for differentiator */
    float error;		/* command - feedback */
    float maxposerror;  /* status: maximum position error so far */
    float error_i;		/* opt. param: integrated error */
    float prev_error;	/* previous error for differentiator */
    float error_d;		/* opt. param: differentiated error */
    float cmd_d;		/* opt. param: differentiated command */
    float output;		/* the output value */
    short enable;		/* enable input */
    short limit_state;	/* 1 if in limit, else 0 */
};
