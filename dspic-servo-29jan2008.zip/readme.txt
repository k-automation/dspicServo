readme.txt
Jan 29 2008 lpg	- added this file to keep track of changes
				- added inverted direction pin on E3 (normal on E2)
				to support dual (full H bridge) board. See V5 hardware.